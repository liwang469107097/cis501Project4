﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cis501.Sales501.PA2
{
    class database
    {
        //Dictionary stores transactions and items
        private Dictionary<transaction, List<item>> data;

        public Dictionary<transaction, List<item>> Data
        {
            get
            {
                return data;
            }
        }

        //Constructor
        public database()
        {
            data = new Dictionary<transaction, List<item>>();
        }

        //Add transaction
        public transaction addTransaction(string id, string date)
        {
            transaction tran = new transaction(id, date);
            data.Add(tran, new List<item>());
            return tran;
        }

        //Add item to dictionary in relate to transaction
        public void addItem(transaction tran, string itemName, float itemValue)
        {
            List<item> items;
            if(data.TryGetValue(tran, out items))
            {
                items.Add(new item(itemName, itemValue));
            }
        }

        //print database
        public bool printDatabase()
        {
            bool processed = false;
            foreach(KeyValuePair<transaction, List<item>> pair in data)
            {
                for (int i = 0; i < pair.Value.Count; i++)
                {
                    processed = true;
                    Console.WriteLine(pair.Key.Id + " " + pair.Value[i].Name + " $" + pair.Value[i].Value);
                }
            }
            return processed;
        }

        //Find a transaction from the dictionary
        public transaction tryGetKey(string transactionID)
        {
            foreach(KeyValuePair<transaction, List<item>> pair in data)
            {
                if (pair.Key.Id.Equals(transactionID))
                {
                    return pair.Key;
                }
            }
            return null;
        }

        //Remove item from dictionary
        public bool removeItem(string transactionID, string itemName)
        {
            List<item> items;
            transaction tran = tryGetKey(transactionID);
            if(tran != null)
            {
                if(data.TryGetValue(tran, out items))
                {
                    foreach(item i in items)
                    {
                        if (i.Name.Equals(itemName))
                        {
                            items.Remove(i);
                            tran.RebateValue = 0;
                            foreach (item k in data[tran])
                            {
                                tran.RebateValue += k.Value;
                            }
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        
    }
}
