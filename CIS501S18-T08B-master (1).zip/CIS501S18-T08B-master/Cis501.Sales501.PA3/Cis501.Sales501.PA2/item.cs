﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cis501.Sales501.PA2
{
    class item
    {
        private string name;
        private float value;

        public item(string itemName, float itemValue)
        {
            name = itemName;
            value = itemValue;
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public float Value
        {
            get { return value; }
            set { value = value; }
        }
    }
}
