﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cis501.Sales501.PA2
{
    static class program
    {
        static void Main(string[] args)
        { 
        }
    }
}
