﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cis501.Sales501.PA2
{
    class manager
    {
        /// <summary>
        /// Database of transactions with items
        /// </summary>
        private database db;
        private databaseRebate dbRebate;

        public manager()
        {
            db = new database();
            dbRebate = new databaseRebate(db);
        }

        public void userInterface()
        {
            Console.WriteLine("Welcome to Sales501!");

            bool quit = false;  // To end the UI
            string input;       // Input for option
            string[] tempStr;   // Using for string splitter

            while (!quit)
            {
                Console.WriteLine("\nWhat would you like to do? \n1) Enter a sale transaction\n2) Return item(s)\n3) Enter rebate\n4) Generate rebate check\n6) Print database\n5) Quit\n");                                 
                input = Console.ReadLine();

                // 1) Enter a sale transaction
                if (input.Equals("1"))
                {
                    //Process transaction id and date
                    Console.Write("\nEnter transaction ID and Purchase date(MMDD, 0619) (separate by space): ");
                    tempStr = Console.ReadLine().Split(' ');
                    transaction tran = db.addTransaction(tempStr[0], tempStr[1]);//enterTransaction(tempStr[0], tempStr[1]);

                    //Process item name and value
                    Console.Write("\nEnter an item's name and value (separate by space): ");
                    tempStr = Console.ReadLine().Split(' ');
                    db.addItem(tran, tempStr[0], float.Parse(tempStr[1]));

                    //Loop for continuelly enter item to transaction
                    while (true)
                    {
                        Console.Write("\nEnter an item's name and value (separate by space) or (q)uit: ");
                        tempStr = Console.ReadLine().Split(' ');
                        if (tempStr[0].Equals("q"))
                        {
                            break;
                        }
                        db.addItem(tran, tempStr[0], float.Parse(tempStr[1]));                     
                    }   
                }

                // 2) Return the item
                if (input.Equals("2"))
                {
                    // Get transaction and item ID
                    Console.Write("\nWhat's transaction ID and item name (separate by space): ");
                    tempStr = Console.ReadLine().Split(' ');

                    // Loop for mutiple items return
                    while (!tempStr[0].Equals("q"))
                    {
                        if(db.removeItem(tempStr[0], tempStr[1]))
                        {
                            Console.WriteLine("Item removed!");
                        }
                        else
                        {
                            Console.WriteLine("No such item or transaction!");
                        }

                        Console.Write("What's transaction ID and item ID (separate by space) or (q)uit: ");
                        tempStr = Console.ReadLine().Split(' ');
                    }
                }

                // 3) Enter the rebate
                if (input.Equals("3"))
                {
                    // Get transaction ID
                    Console.Write("What's transaction ID and Rebate Date(MMDD) (separate by space): ");
                    tempStr = Console.ReadLine().Split(' ');
                    if (dbRebate.processRebate(tempStr[0], Convert.ToInt32(tempStr[1])))
                    {
                        Console.WriteLine("Successfully processed rebate! ");
                    }
                    else
                    {
                        Console.WriteLine("Unable to process!");
                    }
                }

                // 4) Process all rebatable transactions
                if (input.Equals("4"))
                {
                    if (!dbRebate.processRebateChecks())
                    {
                        Console.WriteLine("No rebates available to process!");
                    }
                }

                // Quit the UI
                if (input.Equals("5"))
                {
                    quit = true;
                    Console.WriteLine("Have a lovely day, my friend.\n");
                }

                // Print the database for debugging
                if (input.Equals("6"))
                {
                    if (!db.printDatabase())
                    {
                        Console.WriteLine("Nothing in the dababase, mate!");
                    }
                }

            }
        }
    }

    
}
