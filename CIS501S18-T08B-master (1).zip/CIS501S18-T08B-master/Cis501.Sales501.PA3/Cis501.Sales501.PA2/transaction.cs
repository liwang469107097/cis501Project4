﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cis501.Sales501.PA2
{
    class transaction
    {
        private string id;
        private string date;
        private bool rebated = false;
        private bool willRebate = false;
        private float rebateValue = 0;

        public transaction(string id, string date)
        {
            this.id = id;
            this.date = date;
        }

        public string Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Date
        {
            get { return date; }
            set { date = value; }
        }

        public bool Rebated
        {
            get { return rebated; }
            set { rebated = value; }
        }

        public bool WillRebate
        {
            get { return willRebate; }
            set { willRebate = value; }
        }

        public float RebateValue
        {
            get { return rebateValue; }
            set { rebateValue = value; }
        }
    }
}
