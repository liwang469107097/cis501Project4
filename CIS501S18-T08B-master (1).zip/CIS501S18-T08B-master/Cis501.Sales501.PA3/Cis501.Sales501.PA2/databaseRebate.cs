﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cis501.Sales501.PA2
{
    class databaseRebate
    {
        private database db;

        public databaseRebate(database db)
        {
            this.db = db;
        }

        //Add rebate to database
        public bool processRebate(string transactionID, int rebateDate)
        {
            transaction tran = db.tryGetKey(transactionID);
            if (tran != null)
            {
                if (tran.Date.Substring(0, 2).Equals("06") && rebateDate <= 0719)
                {
                    tran.WillRebate = true;
                    tran.RebateValue = 0;
                    foreach (item i in db.Data[tran])
                    {
                        tran.RebateValue += i.Value;
                    }
                    Console.WriteLine("Transaction value $" + tran.RebateValue);
                    tran.RebateValue = (float)(tran.RebateValue * 0.11);
                    Console.WriteLine("Rebate value $" + tran.RebateValue);
                    return true;
                }
            }
            return false;
        }

        //Process rabate checks
        public bool processRebateChecks()
        {
            bool processed = false;
            foreach (KeyValuePair<transaction, List<item>> pair in db.Data)
            {
                transaction tran = pair.Key;
                if (tran.WillRebate)
                {
                    tran.WillRebate = false;
                    processed = true;
                    Console.WriteLine("Check for transaction " + tran.Id + " with $" + tran.RebateValue + " is processed!");
                }
            }
            return processed;
        }
    }
}
