﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4_Sol
{
    /// <summary>
    /// a class for rebate database
    /// </summary>
    class RebateDB
    {
        /// <summary>
        /// a dictionary for store id and rebate data
        /// </summary>
        private Dictionary<int, Rebate> dic;

        /// <summary>
        /// constructor for rebate database
        /// </summary>
        public RebateDB()
        {
            dic = new Dictionary<int, Rebate>();
        }

        /// <summary>
        /// add data to database
        /// </summary>
        /// <param name="id">given id</param>
        /// <param name="data">given rebate data</param>
        public void addData(int id, Rebate data)
        {
            dic.Add(id, data);
        }

        /// <summary>
        /// get database
        /// </summary>
        /// <returns></returns>
        public Dictionary<int, Rebate> getData()
        {
            return dic;
        }

        /// <summary>
        /// set data
        /// </summary>
        /// <param name="dic"></param>
        public void setData(Dictionary<int, Rebate> dic)
        {
            this.dic = dic;
        }
    }
}
