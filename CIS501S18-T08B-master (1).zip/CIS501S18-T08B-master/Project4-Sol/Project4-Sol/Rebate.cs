﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4_Sol
{
    /// <summary>
    /// a class for rebate
    /// </summary>
    class Rebate
    {
        /// <summary>
        /// whehter it is rebated
        /// </summary>
        private bool rebated;

        /// <summary>
        /// rebate value
        /// </summary>
        private float rebateValue;

        /// <summary>
        /// constructor rebate
        /// </summary>
        /// <param name="value">given value</param>
        public Rebate(float value)
        {
            rebateValue = value;
            rebated = false;
        }

        /// <summary>
        /// get  to determine whether it is rebated
        /// </summary>
        public bool Rebated
        {
            set
            {
                rebated = value;
            }
            get
            {
                return rebated;
            }
        }

        /// <summary>
        /// get and set rebate value
        /// </summary>
        public float RebateValue
        {
            get
            {
                return rebateValue;
            }
            set
            {
                rebateValue = value;
            }
        }
    }
}
