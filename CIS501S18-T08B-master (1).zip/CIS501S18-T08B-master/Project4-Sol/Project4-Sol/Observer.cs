﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4_Sol
{
    /// <summary>
    /// delegate for observer update
    /// </summary>
    /// <param name="state">given state</param>
    /// <param name="obj">given object for result</param>
    public delegate void Observer(Status state, Object obj);
}
