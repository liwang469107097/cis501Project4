﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4_Sol
{
    /// <summary>
    /// delegate for enter rebate handle
    /// </summary>
    /// <param name="update">given update</param>
    /// <param name="tranId">given transaction id</param>
    /// <param name="date">given date</param>
    public delegate void EnterRebateHandle(Observer update, int tranId, int date);
}
