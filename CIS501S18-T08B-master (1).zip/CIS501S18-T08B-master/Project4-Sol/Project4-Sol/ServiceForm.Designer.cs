﻿namespace Project4_Sol
{
    partial class ServiceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uxIDLabel = new System.Windows.Forms.Label();
            this.uxItemLabel = new System.Windows.Forms.Label();
            this.uxReturn = new System.Windows.Forms.Button();
            this.uxID = new System.Windows.Forms.TextBox();
            this.uxItem = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // uxIDLabel
            // 
            this.uxIDLabel.AutoSize = true;
            this.uxIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxIDLabel.Location = new System.Drawing.Point(16, 17);
            this.uxIDLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.uxIDLabel.Name = "uxIDLabel";
            this.uxIDLabel.Size = new System.Drawing.Size(174, 29);
            this.uxIDLabel.TabIndex = 0;
            this.uxIDLabel.Text = "Transaction ID:";
            // 
            // uxItemLabel
            // 
            this.uxItemLabel.AutoSize = true;
            this.uxItemLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxItemLabel.Location = new System.Drawing.Point(16, 65);
            this.uxItemLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.uxItemLabel.Name = "uxItemLabel";
            this.uxItemLabel.Size = new System.Drawing.Size(162, 29);
            this.uxItemLabel.TabIndex = 1;
            this.uxItemLabel.Text = "Name of Item:";
            // 
            // uxReturn
            // 
            this.uxReturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxReturn.Location = new System.Drawing.Point(21, 122);
            this.uxReturn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.uxReturn.Name = "uxReturn";
            this.uxReturn.Size = new System.Drawing.Size(703, 49);
            this.uxReturn.TabIndex = 2;
            this.uxReturn.Text = "Return";
            this.uxReturn.UseVisualStyleBackColor = true;
            this.uxReturn.Click += new System.EventHandler(this.uxReturn_Click);
            // 
            // uxID
            // 
            this.uxID.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxID.Location = new System.Drawing.Point(244, 15);
            this.uxID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.uxID.Name = "uxID";
            this.uxID.Size = new System.Drawing.Size(480, 34);
            this.uxID.TabIndex = 3;
            this.uxID.TextChanged += new System.EventHandler(this.uxID_TextChanged);
            // 
            // uxItem
            // 
            this.uxItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxItem.Location = new System.Drawing.Point(244, 65);
            this.uxItem.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.uxItem.Name = "uxItem";
            this.uxItem.Size = new System.Drawing.Size(480, 34);
            this.uxItem.TabIndex = 6;
            this.uxItem.TextChanged += new System.EventHandler(this.uxItem_TextChanged);
            // 
            // ServiceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(749, 187);
            this.Controls.Add(this.uxItem);
            this.Controls.Add(this.uxID);
            this.Controls.Add(this.uxReturn);
            this.Controls.Add(this.uxItemLabel);
            this.Controls.Add(this.uxIDLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "ServiceForm";
            this.Text = "ServiceForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label uxIDLabel;
        private System.Windows.Forms.Label uxItemLabel;
        private System.Windows.Forms.Button uxReturn;
        private System.Windows.Forms.TextBox uxID;
        private System.Windows.Forms.TextBox uxItem;
    }
}