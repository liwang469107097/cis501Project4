﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4_Sol
{
    /// <summary>
    /// enum for status
    /// </summary>
    public enum Status { Start, CreateTran, Rturn, EnterRebate, GenerateRebate, Success, Failure, AddItem, Close};
}
