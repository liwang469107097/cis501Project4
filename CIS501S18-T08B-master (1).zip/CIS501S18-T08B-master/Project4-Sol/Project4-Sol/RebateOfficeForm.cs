﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project4_Sol
{
    public partial class RebateOfficeForm : Form
    {
        private EnterRebateHandle enterRebateHandle;
        private ProcessRebateHandle processRebateHandle;

        public RebateOfficeForm(EnterRebateHandle enterRebateHandle, ProcessRebateHandle processRebateHandle)
        {
            InitializeComponent();
            uxEnterRebate.Enabled = false;
            this.enterRebateHandle = enterRebateHandle;
            this.processRebateHandle = processRebateHandle;
        }

        private void uxRebate_Click(object sender, EventArgs e)
        {
            enterRebateHandle(this.update, Convert.ToInt32(uxID.Text), Convert.ToInt32(uxRebateDate.Text));
            uxRebateDate.Text = "";
            uxID.Text = "";
        }

        private void uxID_TextChanged(object sender, EventArgs e)
        {
            if (uxID.Text != "" && uxRebateDate.Text != "")
            {
                uxEnterRebate.Enabled = true;
            }
            else
            {
                uxEnterRebate.Enabled = false;
            }
        }

        private void uxRebateDate_TextChanged(object sender, EventArgs e)
        {
            if (uxID.Text != "" && uxRebateDate.Text != "")
            {
                uxEnterRebate.Enabled = true;
            }
            else
            {
                uxEnterRebate.Enabled = false;
            }
        }

        private void uxGenerateCheck_Click(object sender, EventArgs e)
        {
            processRebateHandle(this.update);
        }

        public void update(Status state, Object obj)
        {
            switch (state)
            {
                case Status.EnterRebate:
                    MessageBox.Show(obj.ToString());
                    break;
                case Status.GenerateRebate:
                    if (Convert.ToSingle(obj) != 0)
                    {
                        MessageBox.Show("The checks' value of " + obj.ToString() + " are sent");
                    }
                    else
                    {
                        MessageBox.Show("No checks can be sent!");
                    }
                    break;
            }
            
        
    
        }
    }
}
