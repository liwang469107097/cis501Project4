﻿namespace Project4_Sol
{
    partial class CashierForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uxIDLabel = new System.Windows.Forms.Label();
            this.uxID = new System.Windows.Forms.TextBox();
            this.uxDateLabel = new System.Windows.Forms.Label();
            this.uxItemLabel = new System.Windows.Forms.Label();
            this.uxDate = new System.Windows.Forms.TextBox();
            this.uxItem = new System.Windows.Forms.TextBox();
            this.uxValueLabel = new System.Windows.Forms.Label();
            this.uxValue = new System.Windows.Forms.TextBox();
            this.uxAdd = new System.Windows.Forms.Button();
            this.uxCreate = new System.Windows.Forms.Button();
            this.uxDone = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // uxIDLabel
            // 
            this.uxIDLabel.AutoSize = true;
            this.uxIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxIDLabel.Location = new System.Drawing.Point(12, 12);
            this.uxIDLabel.Name = "uxIDLabel";
            this.uxIDLabel.Size = new System.Drawing.Size(174, 29);
            this.uxIDLabel.TabIndex = 0;
            this.uxIDLabel.Text = "Transaction ID:";
            // 
            // uxID
            // 
            this.uxID.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxID.Location = new System.Drawing.Point(190, 10);
            this.uxID.Name = "uxID";
            this.uxID.Size = new System.Drawing.Size(342, 34);
            this.uxID.TabIndex = 1;
            this.uxID.TextChanged += new System.EventHandler(this.uxID_TextChanged);
            // 
            // uxDateLabel
            // 
            this.uxDateLabel.AutoSize = true;
            this.uxDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxDateLabel.Location = new System.Drawing.Point(12, 53);
            this.uxDateLabel.Name = "uxDateLabel";
            this.uxDateLabel.Size = new System.Drawing.Size(176, 29);
            this.uxDateLabel.TabIndex = 2;
            this.uxDateLabel.Text = "Purchase Date:";
            // 
            // uxItemLabel
            // 
            this.uxItemLabel.AutoSize = true;
            this.uxItemLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxItemLabel.Location = new System.Drawing.Point(13, 86);
            this.uxItemLabel.Name = "uxItemLabel";
            this.uxItemLabel.Size = new System.Drawing.Size(162, 29);
            this.uxItemLabel.TabIndex = 4;
            this.uxItemLabel.Text = "Name of Item:";
            this.uxItemLabel.Click += new System.EventHandler(this.uxItemLabel_Click);
            // 
            // uxDate
            // 
            this.uxDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxDate.Location = new System.Drawing.Point(190, 48);
            this.uxDate.Name = "uxDate";
            this.uxDate.Size = new System.Drawing.Size(342, 34);
            this.uxDate.TabIndex = 5;
            this.uxDate.TextChanged += new System.EventHandler(this.uxDate_TextChanged);
            // 
            // uxItem
            // 
            this.uxItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxItem.Location = new System.Drawing.Point(190, 82);
            this.uxItem.Name = "uxItem";
            this.uxItem.Size = new System.Drawing.Size(342, 34);
            this.uxItem.TabIndex = 6;
            this.uxItem.TextChanged += new System.EventHandler(this.uxItem_TextChanged);
            // 
            // uxValueLabel
            // 
            this.uxValueLabel.AutoSize = true;
            this.uxValueLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxValueLabel.Location = new System.Drawing.Point(13, 120);
            this.uxValueLabel.Name = "uxValueLabel";
            this.uxValueLabel.Size = new System.Drawing.Size(80, 29);
            this.uxValueLabel.TabIndex = 7;
            this.uxValueLabel.Text = "Value:";
            // 
            // uxValue
            // 
            this.uxValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxValue.Location = new System.Drawing.Point(190, 116);
            this.uxValue.Name = "uxValue";
            this.uxValue.Size = new System.Drawing.Size(342, 34);
            this.uxValue.TabIndex = 8;
            this.uxValue.TextChanged += new System.EventHandler(this.uxValue_TextChanged);
            // 
            // uxAdd
            // 
            this.uxAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxAdd.Location = new System.Drawing.Point(13, 156);
            this.uxAdd.Name = "uxAdd";
            this.uxAdd.Size = new System.Drawing.Size(519, 43);
            this.uxAdd.TabIndex = 9;
            this.uxAdd.Text = "Add Item";
            this.uxAdd.UseVisualStyleBackColor = true;
            this.uxAdd.Click += new System.EventHandler(this.uxAdd_Click);
            // 
            // uxCreate
            // 
            this.uxCreate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxCreate.Location = new System.Drawing.Point(12, 205);
            this.uxCreate.Name = "uxCreate";
            this.uxCreate.Size = new System.Drawing.Size(253, 43);
            this.uxCreate.TabIndex = 12;
            this.uxCreate.Text = "Create Transaction";
            this.uxCreate.UseVisualStyleBackColor = true;
            this.uxCreate.Click += new System.EventHandler(this.uxCreate_Click);
            // 
            // uxDone
            // 
            this.uxDone.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxDone.Location = new System.Drawing.Point(279, 205);
            this.uxDone.Name = "uxDone";
            this.uxDone.Size = new System.Drawing.Size(253, 43);
            this.uxDone.TabIndex = 13;
            this.uxDone.Text = "Done Create Transaction";
            this.uxDone.UseVisualStyleBackColor = true;
            this.uxDone.Click += new System.EventHandler(this.uxCancel_Click);
            // 
            // CashierForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 264);
            this.Controls.Add(this.uxDone);
            this.Controls.Add(this.uxCreate);
            this.Controls.Add(this.uxAdd);
            this.Controls.Add(this.uxValue);
            this.Controls.Add(this.uxValueLabel);
            this.Controls.Add(this.uxItem);
            this.Controls.Add(this.uxDate);
            this.Controls.Add(this.uxItemLabel);
            this.Controls.Add(this.uxDateLabel);
            this.Controls.Add(this.uxID);
            this.Controls.Add(this.uxIDLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "CashierForm";
            this.Text = "Cashier";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label uxIDLabel;
        private System.Windows.Forms.TextBox uxID;
        private System.Windows.Forms.Label uxDateLabel;
        private System.Windows.Forms.Label uxItemLabel;
        private System.Windows.Forms.TextBox uxDate;
        private System.Windows.Forms.TextBox uxItem;
        private System.Windows.Forms.Label uxValueLabel;
        private System.Windows.Forms.TextBox uxValue;
        private System.Windows.Forms.Button uxAdd;
        private System.Windows.Forms.Button uxCreate;
        private System.Windows.Forms.Button uxDone;
    }
}

