﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4_Sol
{
    /// <summary>
    /// a class for create transaction controller
    /// </summary>
    class CreateTransaction
    {
        /// <summary>
        /// transaction database
        /// </summary>
        private TransactionDB _tranDB;

        /// <summary>
        /// constructor for create transaction
        /// </summary>
        /// <param name="tranDB">given transaction database</param>
        public CreateTransaction(TransactionDB tranDB)
        {
            _tranDB = tranDB;
        }

        /// <summary>
        /// the handle method for create trasaction controller with delegate
        /// </summary>
        /// <param name="update"> given update </param>
        /// <param name="id">given id</param>
        /// <param name="date">given date</param>
        /// <param name="item">given item</param>
        /// <param name="value"> given value</param>
        public void Handle(Observer update, int id, int date, string item, float value)
        {
                Dictionary<int, Transaction> db = _tranDB.GetDB();
                Transaction tran;
                Item i = new Item(item, value);
                List<Item> list;
                if (db.TryGetValue(id, out tran))
                {
                    list = tran.GetItems();
                    list.Add(i);
                    tran.setItems(list);
                    _tranDB.Motify(id, tran);
                    update(Status.CreateTran, false);
                }
                else
                {

                    list = new List<Item>();
                    list.Add(i);
                    tran = new Transaction(date, list);
                    _tranDB.Add(id, tran);
                    update(Status.CreateTran, true);
                }
            

            
        }
    }
}
