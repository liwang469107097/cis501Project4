﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4_Sol
{
    /// <summary>
    /// a class for item
    /// </summary>
    class Item
    {
        /// <summary>
        /// item name
        /// </summary>
        private string _name;

        /// <summary>
        /// item value
        /// </summary>
        private float _value;

        /// <summary>
        /// construcor for item
        /// </summary>
        /// <param name="name">given item's name</param>
        /// <param name="value">given item's value</param>
        public Item(string name, float value)
        {
            _name = name;
            _value = value;
        }

        /// <summary>
        /// get item's value
        /// </summary>
        public float Value
        {
            get
            {
                return _value;
            }
        }

        /// <summary>
        /// get item's name
        /// </summary>
        public string Name
        {
            get
            {
                return _name;
            }
        }

    }
}
