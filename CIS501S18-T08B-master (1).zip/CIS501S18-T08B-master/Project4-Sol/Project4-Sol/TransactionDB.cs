﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4_Sol
{
    /// <summary>
    /// a class for transaction database
    /// </summary>
    class TransactionDB
    {
        /// <summary>
        /// a dictionary for store the ide and transaction data
        /// </summary>
        private Dictionary<int, Transaction> _db;

        /// <summary>
        /// constructor for transaction database
        /// </summary>
        public TransactionDB()
        {
            _db = new Dictionary<int, Transaction>();
        }
        
        /// <summary>
        /// add id and transaction data to database dictionary
        /// </summary>
        /// <param name="id">given id</param>
        /// <param name="tran">given transaction</param>
        public void Add(int id, Transaction tran)
        {
            _db.Add(id, tran);
        }

        /// <summary>
        /// get database
        /// </summary>
        /// <returns></returns>
        public Dictionary<int, Transaction> GetDB()
        {
            return _db;
        }

        /// <summary>
        /// motify the transaction data in database dictionary
        /// </summary>
        /// <param name="id">given id</param>
        /// <param name="tran">given transaction data</param>
        public void Motify(int id, Transaction tran)
        {
            _db[id] = tran;
        }
    }
}
