﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4_Sol
{
    /// <summary>
    /// delegate for process rebate handle
    /// </summary>
    /// <param name="update"></param>
    public delegate void ProcessRebateHandle(Observer update);
}
