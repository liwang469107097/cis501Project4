﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project4_Sol
{
    public partial class ServiceForm : Form
    {
        private ReturnHandle _return;

        public ServiceForm(ReturnHandle r)
        {
            _return = r;
            InitializeComponent();
            uxReturn.Enabled = false;
        }

        private void uxReturn_Click(object sender, EventArgs e)
        {
             _return(this.Update, Convert.ToInt32(uxID.Text), uxItem.Text);
        }

        private void uxID_TextChanged(object sender, EventArgs e)
        {
            if (uxID.Text != "" && uxItem.Text != "")
                uxReturn.Enabled = true;
            else
                uxReturn.Enabled = false;
        }

        private void uxItem_TextChanged(object sender, EventArgs e)
        {
            if (uxID.Text != "" && uxItem.Text != "")
                uxReturn.Enabled = true;
            else
                uxReturn.Enabled = false;
        }

        private void uxValue_TextChanged(object sender, EventArgs e)
        {
            if (uxID.Text != "" && uxItem.Text != "")
                uxReturn.Enabled = true;
            else
                uxReturn.Enabled = false;
        }

        public void Update(Status state, Object obj)
        {
            if(obj != null)
            {
                MessageBox.Show("Item " + obj.ToString() + " successfully returned!");
            }
            else
            {
                MessageBox.Show("Unable to return!");
            }
        }
    }
}
