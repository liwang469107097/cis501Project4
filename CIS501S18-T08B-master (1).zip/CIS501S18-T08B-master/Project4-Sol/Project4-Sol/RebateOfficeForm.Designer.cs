﻿namespace Project4_Sol
{
    partial class RebateOfficeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uxRebateDate = new System.Windows.Forms.TextBox();
            this.uxCurrentDataLable = new System.Windows.Forms.Label();
            this.uxEnterRebate = new System.Windows.Forms.Button();
            this.uxGenerateCheck = new System.Windows.Forms.Button();
            this.uxIDLabel = new System.Windows.Forms.Label();
            this.uxID = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // uxRebateDate
            // 
            this.uxRebateDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxRebateDate.Location = new System.Drawing.Point(160, 50);
            this.uxRebateDate.Name = "uxRebateDate";
            this.uxRebateDate.Size = new System.Drawing.Size(356, 34);
            this.uxRebateDate.TabIndex = 7;
            this.uxRebateDate.TextChanged += new System.EventHandler(this.uxRebateDate_TextChanged);
            // 
            // uxCurrentDataLable
            // 
            this.uxCurrentDataLable.AutoSize = true;
            this.uxCurrentDataLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxCurrentDataLable.Location = new System.Drawing.Point(12, 49);
            this.uxCurrentDataLable.Name = "uxCurrentDataLable";
            this.uxCurrentDataLable.Size = new System.Drawing.Size(154, 29);
            this.uxCurrentDataLable.TabIndex = 5;
            this.uxCurrentDataLable.Text = "Current Date:";
            // 
            // uxEnterRebate
            // 
            this.uxEnterRebate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxEnterRebate.Location = new System.Drawing.Point(16, 114);
            this.uxEnterRebate.Name = "uxEnterRebate";
            this.uxEnterRebate.Size = new System.Drawing.Size(500, 40);
            this.uxEnterRebate.TabIndex = 8;
            this.uxEnterRebate.Text = "Enter Rebate";
            this.uxEnterRebate.UseVisualStyleBackColor = true;
            this.uxEnterRebate.Click += new System.EventHandler(this.uxRebate_Click);
            // 
            // uxGenerateCheck
            // 
            this.uxGenerateCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxGenerateCheck.Location = new System.Drawing.Point(16, 174);
            this.uxGenerateCheck.Name = "uxGenerateCheck";
            this.uxGenerateCheck.Size = new System.Drawing.Size(500, 40);
            this.uxGenerateCheck.TabIndex = 9;
            this.uxGenerateCheck.Text = "Generate Rebate\'s Check";
            this.uxGenerateCheck.UseVisualStyleBackColor = true;
            this.uxGenerateCheck.Click += new System.EventHandler(this.uxGenerateCheck_Click);
            // 
            // uxIDLabel
            // 
            this.uxIDLabel.AutoSize = true;
            this.uxIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxIDLabel.Location = new System.Drawing.Point(12, 9);
            this.uxIDLabel.Name = "uxIDLabel";
            this.uxIDLabel.Size = new System.Drawing.Size(174, 29);
            this.uxIDLabel.TabIndex = 10;
            this.uxIDLabel.Text = "Transaction ID:";
            // 
            // uxID
            // 
            this.uxID.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxID.Location = new System.Drawing.Point(160, 11);
            this.uxID.Name = "uxID";
            this.uxID.Size = new System.Drawing.Size(356, 34);
            this.uxID.TabIndex = 11;
            this.uxID.TextChanged += new System.EventHandler(this.uxID_TextChanged);
            // 
            // RebateOfficeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(564, 250);
            this.Controls.Add(this.uxID);
            this.Controls.Add(this.uxIDLabel);
            this.Controls.Add(this.uxGenerateCheck);
            this.Controls.Add(this.uxEnterRebate);
            this.Controls.Add(this.uxRebateDate);
            this.Controls.Add(this.uxCurrentDataLable);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "RebateOfficeForm";
            this.Text = "RebateOfficeForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox uxRebateDate;
        private System.Windows.Forms.Label uxCurrentDataLable;
        private System.Windows.Forms.Button uxEnterRebate;
        private System.Windows.Forms.Button uxGenerateCheck;
        private System.Windows.Forms.Label uxIDLabel;
        private System.Windows.Forms.TextBox uxID;
    }
}