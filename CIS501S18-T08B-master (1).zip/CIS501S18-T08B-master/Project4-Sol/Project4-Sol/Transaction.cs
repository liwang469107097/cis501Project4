﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4_Sol
{
    /// <summary>
    /// a class for transaction data
    /// </summary>
    class Transaction
    {
        /// <summary>
        /// date
        /// </summary>
        private int _date;

        /// <summary>
        /// a list of items 
        /// </summary>
        private List<Item> _items;

        /// <summary>
        /// constructor for transaction data
        /// </summary>
        /// <param name="date">given date</param>
        /// <param name="items">given list of items</param>
        public Transaction(int date, List<Item> items)
        {
            _date = date;
            _items = items;
        }

        /// <summary>
        /// get items 
        /// </summary>
        /// <returns></returns>
        public List<Item> GetItems()
        {
            return _items;
        }

        /// <summary>
        /// set items
        /// </summary>
        /// <param name="_items"></param>
        public void setItems(List<Item> _items)
        {
            this._items = _items;
        }

        public int Date {
            get
            {
                return _date;
            }
        }

    }
}
