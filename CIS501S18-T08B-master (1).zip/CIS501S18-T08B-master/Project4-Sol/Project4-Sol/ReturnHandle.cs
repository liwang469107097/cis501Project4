﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4_Sol
{
    /// <summary>
    /// delegate for return handle
    /// </summary>
    /// <param name="update"></param>
    /// <param name="id"></param>
    /// <param name="item"></param>
    public delegate void ReturnHandle(Observer update, int id, string item);
}
