﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4_Sol
{
    /// <summary>
    /// a class for return item controller
    /// </summary>
    class ReturnItems
    {
        /// <summary>
        /// transaction database
        /// </summary>
        private TransactionDB _tranDB;

        /// <summary>
        /// constructor for return items controller
        /// </summary>
        /// <param name="tranDB">given transaction database</param>
        public ReturnItems(TransactionDB tranDB)
        {
            _tranDB = tranDB;
        }
        
        /// <summary>
        /// handle method for return item controller with delegate
        /// </summary>
        /// <param name="update"></param>
        /// <param name="id"></param>
        /// <param name="item"></param>
        public void Handle(Observer update, int id, string item)
        {
            Dictionary<int, Transaction> db = _tranDB.GetDB();
            Transaction tran;
            if (db.TryGetValue(id, out tran))
            {
                List<Item> list = tran.GetItems();
                foreach(Item i in list)
                {
                    if (i.Name.CompareTo(item) == 0)
                    {
                        list.Remove(i);
                        tran.setItems(list);
                        _tranDB.Motify(id, tran);
                        update(Status.Rturn, item);
                        return;
                    }
                }                
            }
            update(Status.Rturn, null);
        }
    }
}
