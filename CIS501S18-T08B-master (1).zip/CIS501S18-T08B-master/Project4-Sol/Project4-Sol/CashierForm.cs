﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project4_Sol
{
    /// <summary>
    /// a class for create a cashier's form
    /// </summary>
    public partial class CashierForm : Form
    {
        /// <summary>
        /// create transaction handle
        /// </summary>
        private CreateTranHandle _tran;

        /// <summary>
        /// id
        /// </summary>
        private int _id;

        /// <summary>
        /// date
        /// </summary>
        private int _date;
        

        /// <summary>
        /// construct GUI
        /// </summary>
        /// <param name="tran">given create transaction handle</param>
        public CashierForm(CreateTranHandle tran)
        {
            _tran = tran;
            InitializeComponent();
            uxAdd.Enabled = false;
            uxCreate.Enabled = false;
            uxDone.Enabled = false;
            uxItem.Enabled = false;
            uxValue.Enabled = false;
        }

        /// <summary>
        /// no use
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxItemLabel_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// text box for item's name
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxItem_TextChanged(object sender, EventArgs e)
        {
            if (uxItem.Text != "" && uxValue.Text != "")
            {
                uxAdd.Enabled = true;
            }
            else
            {
                uxAdd.Enabled = false;
            }
        }

        /// <summary>
        /// event handle for add more item
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxAdd_Click(object sender, EventArgs e)
        {

            _tran(this.Update, _id, _date, uxItem.Text, Convert.ToSingle(uxValue.Text));
            uxItem.Clear();
            uxValue.Clear();
            uxDone.Enabled = true;
            
        }

        /// <summary>
        /// event handle for done create transaction 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxCancel_Click(object sender, EventArgs e)
        {
            uxID.Enabled = true;
            uxDate.Enabled = true;
            uxItem.Enabled = false;
            uxValue.Enabled = false;
            uxAdd.Enabled = false;
            uxCreate.Enabled = false;
            uxDone.Enabled = false;
            uxID.Clear();
            uxDate.Clear();
            uxItem.Clear();
            uxValue.Clear();
        }

        /// <summary>
        /// event handler for Create transaction
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxCreate_Click(object sender, EventArgs e)
        {
            _id = Convert.ToInt32(uxID.Text);
            _date = Convert.ToInt32(uxDate.Text);
            uxID.Enabled = false;
            uxDate.Enabled = false;
            uxCreate.Enabled = false;
            uxItem.Enabled = true;
            uxValue.Enabled = true;
            
        }

        /// <summary>
        /// text box for id
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxID_TextChanged(object sender, EventArgs e)
        {
            if (uxID.Text != "" && uxDate.Text != "")
            {
                uxCreate.Enabled = true;
            }
            else
            {
                uxCreate.Enabled = false;
            }
               
        }

        /// <summary>
        /// text box for date
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxDate_TextChanged(object sender, EventArgs e)
        {
            if (uxID.Text != "" && uxDate.Text != "")
            {
                uxCreate.Enabled = true;
            }
            else
            {
                uxCreate.Enabled = false;
            }
        }

        /// <summary>
        /// text box for item's value
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxValue_TextChanged(object sender, EventArgs e)
        {
            if (uxItem.Text != "" && uxValue.Text != "")
            {
                uxAdd.Enabled = true;
            }
            else
            {
                uxAdd.Enabled = false;
            }
        }

        /// <summary>
        /// update method for cashier form
        /// </summary>
        /// <param name="state"></param>
        /// <param name="obj"></param>
        public void Update(Status state, Object obj)
        {
            if ((bool)obj)
            {
                MessageBox.Show("A transaction created and an item added");
            }
            else
                MessageBox.Show("An item added");
        }
         
    }
}
