﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4_Sol
{
    /// <summary>
    /// a class for process rebate check controller
    /// </summary>
    class ProcessRebate
    {
        /// <summary>
        /// rebate database
        /// </summary>
        private RebateDB rebates;

        /// <summary>
        /// constructor for process rebate check controller
        /// </summary>
        /// <param name="rebates">given rebate database</param>
        public ProcessRebate(RebateDB rebates)
        {
            this.rebates = rebates;
        }

        /// <summary>
        /// handle method for process reabate check controller with delegate handle
        /// </summary>
        /// <param name="update"></param>
        public void handle(Observer update)
        {
            Dictionary<int, Rebate> dic = rebates.getData();
            float checkValue = 0;
            foreach(KeyValuePair<int, Rebate> pair in dic)
            {
                if (!pair.Value.Rebated)
                {
                    checkValue += pair.Value.RebateValue;
                    dic[pair.Key].Rebated = true;
                }                
            }
            rebates.setData(dic);
            update(Status.GenerateRebate, checkValue);
        }
    }
}
