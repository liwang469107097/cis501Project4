﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4_Sol
{
    /// <summary>
    /// a class for enter rebate controller
    /// </summary>
    class EnterRebate
    {
        /// <summary>
        /// transaction database
        /// </summary>
        private TransactionDB trans;

        /// <summary>
        /// rebate database
        /// </summary>
        private RebateDB rebates;

        /// <summary>
        /// rebate date
        /// </summary>
        private int rebateDate = 0600;

        /// <summary>
        /// rebate percentage
        /// </summary>
        private double rebatePercentage = .11;

        /// <summary>
        /// a constructor for enter rebate controller
        /// </summary>
        /// <param name="trans"></param>
        /// <param name="rebates"></param>
        public EnterRebate(TransactionDB trans, RebateDB rebates)
        {
            this.trans = trans;
            this.rebates = rebates;
        }

        /// <summary>
        /// handle method for enter rebate controller with delegate
        /// </summary>
        /// <param name="update"></param>
        /// <param name="tranId"></param>
        /// <param name="date"></param>
        public void handle(Observer update, int tranId, int date)
        {
            Dictionary<int, Transaction> dic = trans.GetDB();
            Transaction tran;
            if (dic.TryGetValue(tranId, out tran))
            {
                if (tran.Date > rebateDate && tran.Date < rebateDate + 100)
                {
                    List<Item> items = tran.GetItems();
                    float value = 0;
                    foreach (Item i in items)
                    {
                        value += i.Value;
                    }
                    value *= (float)rebatePercentage;
                    Dictionary<int, Rebate> rebateList = rebates.getData();
                    Rebate rebate;
                    if (rebateList.TryGetValue(tranId, out rebate))
                    {
                        if (!rebate.Rebated)
                        {
                            rebate.RebateValue = value;
                            rebateList[tranId] = rebate;
                            rebates.setData(rebateList);
                            update(Status.EnterRebate, "Rebated $" + value + "!");
                        }
                        else
                        {
                            update(Status.EnterRebate, "The check is sent for this transaction!");
                            return;
                        }
                    }
                    else
                    {
                        rebateList.Add(tranId, new Rebate(value));
                        rebates.setData(rebateList);
                        update(Status.EnterRebate, "Rebated $" + value + "!");
                        return;
                    }
                }
                update(Status.EnterRebate, "Only transactions in the month of June");
                return;
            }
            update(Status.EnterRebate, "No such transaction");
            return;
            
        }
    }
}
