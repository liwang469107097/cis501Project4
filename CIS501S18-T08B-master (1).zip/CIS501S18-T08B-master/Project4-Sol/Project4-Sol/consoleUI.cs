﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4_Sol
{
    /// <summary>
    /// the class for console UI
    /// </summary>
    class consoleUI
    {
        /// <summary>
        /// status begin with start
        /// </summary>
        private Status state = Status.Start;

        /// <summary>
        /// create transaction handle
        /// </summary>
        private CreateTranHandle tranHandle;

        /// <summary>
        /// return item handle
        /// </summary>
        private ReturnHandle returnHandle;

        /// <summary>
        /// enter rebate handle
        /// </summary>
        private EnterRebateHandle enterRebate;

        /// <summary>
        /// process rebate handle
        /// </summary>
        private ProcessRebateHandle processRebateHandle;

        /// <summary>
        /// constructor for console UI
        /// </summary>
        /// <param name="tranHandle">given transaction handle</param>
        /// <param name="returnHandle">given return handle</param>
        /// <param name="enterRebateHandle">given enterrebate handle</param>
        /// <param name="processRebateHandle"> given process rebate handle</param>
        public consoleUI(CreateTranHandle tranHandle, ReturnHandle returnHandle, EnterRebateHandle enterRebateHandle, ProcessRebateHandle processRebateHandle)
        {
            this.tranHandle = tranHandle;
            this.returnHandle = returnHandle;
            this.enterRebate = enterRebateHandle;
            this.processRebateHandle = processRebateHandle;
        }

        /// <summary>
        ///  determine which one user to operate
        /// </summary>
        /// <param name="state">given status </param>
        public void operate(Status state)
        {
            string input;

            while (state != Status.Close)
            {
                switch (state)
                {
                    case Status.Start:
                        displayMenu();
                        input = Console.ReadLine();
                        if (input.CompareTo("1") == 0)
                        {
                            state = Status.CreateTran;
                        }
                        else if (input.CompareTo("2") == 0)
                        {
                            state = Status.Rturn;
                        }
                        else if (input.CompareTo("3") == 0)
                        {
                            state = Status.EnterRebate;
                        }
                        else if (input.CompareTo("4") == 0)
                        {
                            state = Status.GenerateRebate;
                        }
                        else if (input.CompareTo("5") == 0)
                        {
                            state = Status.Close;
                        }
                        break;
                    case Status.CreateTran:
                        createTran();
                        state = Status.Start;
                        break;
                    case Status.Rturn:
                        ReturnI();
                        state = Status.Start;
                        break;
                    case Status.EnterRebate:
                        EnterR();
                        state = Status.Start;
                        break;
                    case Status.GenerateRebate:
                        ProcessCheck();
                        state = Status.Start;
                        break;
                    case Status.Close:
                        return;
                }
                
            }
            Environment.Exit(0);

        }

        /// <summary>
        /// display main menu
        /// </summary>
        public void displayMenu()
        {
            Console.WriteLine("\nPlease choose one number from following below for your need.");
            Console.WriteLine("1. Create sale transaction");
            Console.WriteLine("2. Return item(s)");
            Console.WriteLine("3. Enter rebate");
            Console.WriteLine("4. Generate rebate check");
            Console.WriteLine("5. Exit the system\n");
        }

        /// <summary>
        /// create transaction for console UI
        /// </summary>
        public void createTran()
        {
            try
            {
                string[] input;
                int id;
                int date;
                string item;
                float value;
                
                    Console.WriteLine("Please enter the transaction ID(In integers):");
                    id = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Please enter the date (MMDD):");
                    date = Convert.ToInt32(Console.ReadLine());

                    //Queue<string> items = new Queue<string>();
                    //Queue<float> values = new Queue<float>();

                    Console.WriteLine("Please enter the name and value of the item with space: ");
                    input = Console.ReadLine().Split(' ');

                    do
                    {
                        item = input[0];
                        value = Convert.ToSingle(input[1]);
                        tranHandle(this.update, id, date, item, value);

                        //items.Enqueue(item);
                        //values.Enqueue(value);

                        Console.WriteLine("Please enter the name and value of the item with space or (q)uit: ");
                        input = Console.ReadLine().Split(' ');
                    } while (input[0] != "q");

                
            }
            catch (Exception ex)
            {
                Console.WriteLine("Have an error ocurred: ");
                Console.WriteLine(ex.ToString());
                return;
            }
        }

        /// <summary>
        /// return item for console UI
        /// </summary>
        public void ReturnI()
        {
            try
            {
                string[] input;
                int id;
                string item;

                Console.WriteLine("Please enter the transaction ID and item name with space to return: ");
                input = Console.ReadLine().Split(' ');
                do
                {
                    id = Convert.ToInt32(input[0]);
                    item = input[1];
                    returnHandle(this.update, id, item);
                    Console.WriteLine("Please enter the transaction ID and item name with space to return or (q)uit: ");
                    input = Console.ReadLine().Split(' ');
                } while (input[0] != "q");
                return;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Have an error ocurred: ");
                Console.WriteLine(ex.ToString());
                return;
            }
        }

        /// <summary>
        /// enter rebate for console UI
        /// </summary>
        public void EnterR()
        {
            try
            {
                string input;
                int id;
                int date;
                do
                {
                    Console.WriteLine("\nEnter the rebate: ");
                    Console.Write("Enter the transaction ID: ");
                    id = Convert.ToInt32(Console.ReadLine());

                    Console.Write("Enter the date: ");
                    date = Convert.ToInt32(Console.ReadLine());
                    enterRebate(this.update, id, date);



                    do
                    {
                        Console.Write("\nDo you want to enter another rebate? (Y/N): ");
                        input = Console.ReadLine().ToLower();
                    } while (input != "y" && input != "n");
                } while (input == "y");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Have an error ocurred: ");
                Console.WriteLine(ex.ToString());
                Console.WriteLine("Please re-enter: ");
            }
        }

        /// <summary>
        /// process rebate check for console UI
        /// </summary>
        public void ProcessCheck()
        {
            processRebateHandle(this.update);
        }

        /// <summary>
        /// update method for observer
        /// </summary>
        /// <param name="state">given status</param>
        /// <param name="obj">given object for result</param>
        public void update(Status state, Object obj)
        {
            switch (state)
            {
                case Status.CreateTran:
                    if((bool)obj)
                    {
                        Console.WriteLine("\nTransaction Created\n");
                    }
                    else
                    {
                        Console.WriteLine("\nItem Created\n");
                    }
                    break;
                case Status.EnterRebate:
                    Console.WriteLine(obj.ToString());
                    break;
                case Status.Rturn:
                    if (obj != null)
                    {
                        Console.WriteLine("Item " + obj.ToString() + " is returned");
                    }
                    else
                        Console.WriteLine("Unable to return item");
                    break;
                case Status.GenerateRebate:
                    Console.WriteLine("The checks in the amount of $" + (float)obj + " are processed!");
                    break;                
            }
        }
    }
}

