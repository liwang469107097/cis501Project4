﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4_Sol
{
    /// <summary>
    /// delegate for create transaction handle
    /// </summary>
    /// <param name="update">given update</param>
    /// <param name="id">given id</param>
    /// <param name="date">given date</param>
    /// <param name="item">given item</param>
    /// <param name="value">given value</param>
    public delegate void CreateTranHandle(Observer update, int id, int date, string item, float value);
}
