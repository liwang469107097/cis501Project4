﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Project4_Sol
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            TransactionDB tranDB = new TransactionDB();
            RebateDB rebateDB = new RebateDB();

            CreateTransaction tran = new CreateTransaction(tranDB);
            ReturnItems returnItem = new ReturnItems(tranDB);
            EnterRebate enterRebate = new EnterRebate(tranDB, rebateDB);
            ProcessRebate processRebate = new ProcessRebate(rebateDB);

            EnterRebateHandle h1 = enterRebate.handle;

            Tuple<CreateTranHandle, ReturnHandle, EnterRebateHandle, ProcessRebateHandle> handles = new Tuple<CreateTranHandle, ReturnHandle, EnterRebateHandle, ProcessRebateHandle>(tran.Handle, returnItem.Handle, enterRebate.handle, processRebate.handle);
            new Thread(ConsoleThread).Start(handles);

            new Thread(ReturnItemThread).Start(returnItem);

            Thread cashierForomThread = new Thread(() => CreateTranThread(tran.Handle));
            cashierForomThread.Start();

            Thread rebateOfficeThread = new Thread(() => RebateOffice(enterRebate.handle, processRebate.handle));
            rebateOfficeThread.Start();
        }

        /// <summary>
        /// the thread for console
        /// </summary>
        /// <param name="obj">given object</param>
        static void ConsoleThread(Object obj)
        {
            Tuple<CreateTranHandle, ReturnHandle, EnterRebateHandle, ProcessRebateHandle> tuple = (Tuple<CreateTranHandle, ReturnHandle, EnterRebateHandle, ProcessRebateHandle>)obj;
            consoleUI ui = new consoleUI(tuple.Item1, tuple.Item2, tuple.Item3, tuple.Item4);
            ui.operate(Status.Start);
        }

        /// <summary>
        /// thread for create transaction
        /// </summary>
        /// <param name="tranHandle">given transaction handle</param>
        static void CreateTranThread(CreateTranHandle tranHandle)
        { Application.Run(new CashierForm(tranHandle)); }

        /// <summary>
        /// thread for return item
        /// </summary>
        /// <param name="ob">given object for its handle</param>
        static void ReturnItemThread(Object ob)
        { Application.Run(new ServiceForm(((ReturnItems)ob).Handle)); }

        /// <summary>
        /// thread for rebate office 
        /// </summary>
        /// <param name="handleRebate">given rebate handle</param>
        /// <param name="handleChecks">given check handle</param>
        static void RebateOffice(EnterRebateHandle handleRebate, ProcessRebateHandle handleChecks)
        {
            Application.Run(new RebateOfficeForm(handleRebate, handleChecks));
        }
    }
}
